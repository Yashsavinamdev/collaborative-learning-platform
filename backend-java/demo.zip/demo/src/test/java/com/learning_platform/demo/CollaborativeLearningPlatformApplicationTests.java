package com.learning_platform.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollaborativeLearningPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
